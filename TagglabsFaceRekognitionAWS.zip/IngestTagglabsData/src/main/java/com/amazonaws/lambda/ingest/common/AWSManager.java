package com.amazonaws.lambda.ingest.common;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

public class AWSManager {

	private static AmazonDynamoDB dynamoDB;
	private static AmazonS3 amazonS3;
	private static AmazonRekognition amazonRekognition;
    
	public static AmazonDynamoDB getAmazonDynamoDB() {
        /*
         * The ProfileCredentialsProvider will return your [default]
         * credential profile by reading from the credentials file located at
         * (~/.aws/credentials).
         */
		if (dynamoDB != null)
			return dynamoDB;
//        ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider();
//        try {
//            credentialsProvider.getCredentials();
//        } catch (Exception e) {
//            throw new AmazonClientException(
//                    "Cannot load the credentials from the credential profiles file. " +
//                    "Please make sure that your credentials file is at the correct " +
//                    "location (~/.aws/credentials), and is in valid format.",
//                    e);
//        }
//        dynamoDB = AmazonDynamoDBClientBuilder.standard()
//            .withCredentials(credentialsProvider)
//            .withRegion("us-west-2")
//            .build();
		dynamoDB = AmazonDynamoDBClientBuilder.defaultClient();
        return dynamoDB;
    }
    
	public static AmazonRekognition getAmazonRekognition() {
        /*
         * The ProfileCredentialsProvider will return your [default]
         * credential profile by reading from the credentials file located at
         * (~/.aws/credentials).
         */
		if (amazonRekognition != null)
			return amazonRekognition;
//        ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider();
//        try {
//            credentialsProvider.getCredentials();
//        } catch (Exception e) {
//            throw new AmazonClientException(
//                    "Cannot load the credentials from the credential profiles file. " +
//                    "Please make sure that your credentials file is at the correct " +
//                    "location (~/.aws/credentials), and is in valid format.",
//                    e);
//        }
//        amazonRekognition = AmazonRekognitionClientBuilder.standard()
//            .withCredentials(credentialsProvider)
//            .withRegion("us-west-2")
//            .build();
        amazonRekognition = AmazonRekognitionClientBuilder.defaultClient();
        return amazonRekognition;
    }
    
	public static AmazonS3 getAmazonS3() {
        /*
         * The ProfileCredentialsProvider will return your [default]
         * credential profile by reading from the credentials file located at
         * (~/.aws/credentials).
         */
		if (amazonS3 != null)
			return amazonS3;
//        ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider();
//        try {
//            credentialsProvider.getCredentials();
//        } catch (Exception e) {
//            throw new AmazonClientException(
//                    "Cannot load the credentials from the credential profiles file. " +
//                    "Please make sure that your credentials file is at the correct " +
//                    "location (~/.aws/credentials), and is in valid format.",
//                    e);
//        }
//        amazonS3 = AmazonS3ClientBuilder.standard()
//            .withCredentials(credentialsProvider)
//            .withRegion("us-west-2")
//            .build();
		amazonS3 = AmazonS3ClientBuilder.defaultClient();
        return amazonS3;
    }
}
