package com.amazonaws.lambda.ingest.dao;

import com.amazonaws.lambda.ingest.model.User;

import lombok.NonNull;

public interface RegisterUserDao {

	long getRowCount();

    void saveUser(@NonNull final User user);

}
