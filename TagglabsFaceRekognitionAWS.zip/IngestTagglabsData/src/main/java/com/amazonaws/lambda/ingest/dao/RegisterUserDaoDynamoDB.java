package com.amazonaws.lambda.ingest.dao;

import java.util.HashMap;
import java.util.Map;

import com.amazonaws.lambda.ingest.common.AWSManager;
import com.amazonaws.lambda.ingest.model.User;
import com.amazonaws.lambda.ingest.util.Constants;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.DescribeTableRequest;
import com.amazonaws.services.dynamodbv2.model.DescribeTableResult;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class RegisterUserDaoDynamoDB implements RegisterUserDao {

    @Override
    public long getRowCount() {
        try {
        		final DescribeTableResult result =
        				AWSManager.getAmazonDynamoDB().describeTable(new DescribeTableRequest("Users"));
            return result == null ? 0 : result.getTable().getItemCount();
        } catch (Exception e) {
        		return 0;
        }
    }

    @Override
    public void saveUser(@NonNull final User user) {
    		Map<String, AttributeValue> item = newItem(user);
        PutItemRequest putItemRequest = new PutItemRequest(Constants.DYNAMO_TABLE, item);
        PutItemResult putItemResult = AWSManager.getAmazonDynamoDB().putItem(putItemRequest);
        System.out.println("Result: " + putItemResult);
    }

    private static Map<String, AttributeValue> newItem(User user) {
        Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
        item.put(User.USER_ID, new AttributeValue(user.getUserId()));
        item.put(User.CONTACT_NUMBER, new AttributeValue(user.getContactNumber()));
        item.put(User.EMAIL, new AttributeValue(user.getEmail()));
        item.put(User.NAME, new AttributeValue(user.getName()));
        item.put(User.COMPANY, new AttributeValue(user.getCompany()));
        item.put(User.CLIENT, new AttributeValue(user.getClient()));
        item.put(User.IMAGE_FILE, new AttributeValue(user.getImageFile()));
        return item;
    }
}
