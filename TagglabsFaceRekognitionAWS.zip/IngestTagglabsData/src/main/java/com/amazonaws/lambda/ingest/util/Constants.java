package com.amazonaws.lambda.ingest.util;

public class Constants {
	public static final String COLLECTION_ID = "tagglabs_aws_demo_user_register";

	public static final String S3_BUCKET = "tagglabs-aws-demo-user-register";

	public static final String S3_PROCESSED_BUCKET = "tagglabs-processed";

	public static final String S3_ERRORRED_BUCKET = "tagglabs-errorred";

	public static final String S3_LOGS_BUCKET = "tagglabs-aws-demo-user-register-logs";

	public static final String DYNAMO_TABLE = "Users";
}
