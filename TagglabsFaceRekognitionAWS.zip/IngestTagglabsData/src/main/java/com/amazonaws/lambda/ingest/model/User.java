package com.amazonaws.lambda.ingest.model;

import com.amazonaws.lambda.ingest.util.Constants;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@DynamoDBTable(tableName = Constants.DYNAMO_TABLE)
public class User {

    public static final String CLIENT = "Client";
    public static final String USER_ID = "UserId";
    public static final String EMAIL = "Email";
    public static final String NAME = "Name";
    public static final String CONTACT_NUMBER = "ContactNumber";
    public static final String COMPANY = "Company";
    public static final String IMAGE_FILE = "ImageFile";

    @DynamoDBAttribute(attributeName = CLIENT)
    private String client;

    @DynamoDBAttribute(attributeName = IMAGE_FILE)
    private String imageFile;

    @DynamoDBHashKey(attributeName = EMAIL)
    private String email;

    @DynamoDBAttribute(attributeName = USER_ID)
    private String userId;

    @DynamoDBAttribute(attributeName = NAME)
    private String name;

    @DynamoDBAttribute(attributeName = CONTACT_NUMBER)
    private String contactNumber;

    @DynamoDBAttribute(attributeName = COMPANY)
    private String company;

}
