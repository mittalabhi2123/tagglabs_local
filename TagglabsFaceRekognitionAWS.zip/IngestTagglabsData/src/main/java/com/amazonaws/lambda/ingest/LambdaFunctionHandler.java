package com.amazonaws.lambda.ingest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.amazonaws.lambda.ingest.common.AWSManager;
import com.amazonaws.lambda.ingest.dao.RegisterUserDao;
import com.amazonaws.lambda.ingest.dao.RegisterUserDaoDynamoDB;
import com.amazonaws.lambda.ingest.model.User;
import com.amazonaws.lambda.ingest.util.Constants;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.model.CreateCollectionRequest;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.IndexFacesRequest;
import com.amazonaws.services.rekognition.model.ListCollectionsRequest;
import com.amazonaws.services.rekognition.model.ListCollectionsResult;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.util.StringUtils;

/**
 * Assumptions:
 * 1) All the images will be uploaded together and will be accompanied by a csv file with name of client.
 * 2) For eg: deloitte.csv
 * 3) csv format: <imageFile>,<firstName>,<lastName>,<email>,<phone>
 *
 */
public class LambdaFunctionHandler implements RequestHandler<S3Event, String> {

    private AmazonS3 s3 = AWSManager.getAmazonS3();
	private AmazonRekognition rekognitionClient = AWSManager.getAmazonRekognition();
	private RegisterUserDao dao = new RegisterUserDaoDynamoDB();

    public LambdaFunctionHandler() {}

    // Test purpose only.
    LambdaFunctionHandler(AmazonS3 s3) {
        this.s3 = s3;
    }

    @Override
    public String handleRequest(S3Event event, Context context) {
    		final StringBuilder logs = new StringBuilder();
    		logs.append("\nReceived event: " + event);
    		logs.append("\nCreating Rekognition collection, if not exists......");
        createRekognitionCollection();
        logs.append("\nRekognition collection created.......");
        // Get the object from the event and show its content type
        String bucket = event.getRecords().get(0).getS3().getBucket().getName();
        String key = event.getRecords().get(0).getS3().getObject().getKey();
        List<S3ObjectSummary> processed = new ArrayList<>();
        List<S3ObjectSummary> errorred = new ArrayList<>();
        logs.append("\nNotified for bucket: " + bucket + ", key: " + key);
        try {
            key = URLDecoder.decode(key, "UTF-8");
            String client = convertKeyToClient(key);
    			Map<String, User> userMap = new HashMap<>();
    			parseFile(bucket, key, userMap, logs);
        		ListObjectsV2Result response = s3.listObjectsV2(Constants.S3_BUCKET);
        		for (S3ObjectSummary obj : response.getObjectSummaries()) {
        	        logs.append("\n\tEncountered file bucket: " + obj.getBucketName() + ", key: " + obj.getKey());
        			if (obj.getKey().indexOf("csv") > -1) {
        				processed.add(obj);
        				continue;
        			}
        			try {
	        			logs.append("\n\tIndexing image: " + obj.getKey() + " ...........");
	        			indexImage(obj.getBucketName(), obj.getKey(), userMap.get(obj.getKey()).getUserId());
	        			logs.append("\n\tIndexing completed for image: " + obj.getKey() + " ...........");
	        			dao.saveUser(userMap.get(obj.getKey()));
	        			logs.append("\n\tDynamo data saved for: " + userMap.get(obj.getKey()).getName() + " ...........");
	        			processed.add(obj);
        			} catch (Exception e) {
        				errorred.add(obj);
        			}
        		}
    			for (S3ObjectSummary obj : processed) {
    				CopyObjectRequest cpyRequest = new CopyObjectRequest(obj.getBucketName(), obj.getKey(), Constants.S3_PROCESSED_BUCKET, client+"/"+obj.getKey());
        			s3.copyObject(cpyRequest.withCannedAccessControlList(CannedAccessControlList.PublicRead));
        			s3.deleteObject(obj.getBucketName(), obj.getKey());
    			}
    			for (S3ObjectSummary obj : errorred) {
        			s3.copyObject(obj.getBucketName(), obj.getKey(), Constants.S3_ERRORRED_BUCKET, client+"/"+obj.getKey());
        			s3.deleteObject(obj.getBucketName(), obj.getKey());
    			}
        } catch (Exception e) {
            e.printStackTrace();
            logs.append(String.format("\nError: %s", e.getMessage()));
    			createLogs(logs);
            throw new RuntimeException(e);
        }
    		createLogs(logs);
        return "Data ingested successfully";
    }
    
    private void createLogs(StringBuilder logs) {
    		try {
    	        File file = File.createTempFile("aws-java-sdk-", ".txt");
    	        file.deleteOnExit();

    	        Writer writer = new OutputStreamWriter(new FileOutputStream(file));
    	        writer.write(logs.toString());
    	        writer.close();
    			if (!s3.doesBucketExistV2(Constants.S3_LOGS_BUCKET)) {
    				s3.createBucket(Constants.S3_LOGS_BUCKET);
    			}
    	        s3.putObject(new PutObjectRequest(Constants.S3_LOGS_BUCKET, "logs"+System.currentTimeMillis()+".txt", file));
    		} catch (Exception e) {
        		throw new RuntimeException(e);
        }
    }
	
	private void indexImage(String bucketName, String key, String userId) {
		IndexFacesRequest request = new IndexFacesRequest();
		final Image image = new Image();
		com.amazonaws.services.rekognition.model.S3Object s3Object =
				new com.amazonaws.services.rekognition.model.S3Object();
		s3Object.setBucket(bucketName);
		s3Object.setName(key);
		image.setS3Object(s3Object);
		request.setCollectionId(Constants.COLLECTION_ID);
		request.setExternalImageId(userId);
		request.setImage(image);
		rekognitionClient.indexFaces(request);
	}
	
	private void createRekognitionCollection() {
		ListCollectionsResult result = rekognitionClient.listCollections(new ListCollectionsRequest());
		if (!result.getCollectionIds().contains(Constants.COLLECTION_ID)) {
			CreateCollectionRequest createCollectionRequest = new CreateCollectionRequest();
			createCollectionRequest.setCollectionId(Constants.COLLECTION_ID);
			rekognitionClient.createCollection(createCollectionRequest);
		}
	}
    
    private void parseFile(
    		String bucket, String key, Map<String, User> userMap, StringBuilder context) throws IOException {
    		S3Object fullObject = s3.getObject(new GetObjectRequest(bucket, key));
        String client = convertKeyToClient(key);
        String line = null;
        BufferedReader reader = new BufferedReader(new InputStreamReader(fullObject.getObjectContent()));
        while ((line = reader.readLine()) != null) {
        		context.append("\n" + line);
            User user = new User();
            String[] lineData = line.split(",");
            user.setClient(client);
	    		String firstName = lineData[1];
	    		String lastName = lineData[2];
	    		String name = StringUtils.isNullOrEmpty(firstName) ? "" : firstName.concat(" ").concat(lastName);
	    		user.setName(name.trim());
	    		user.setEmail(lineData[3]);
	    		user.setContactNumber(lineData[4]);
	    		user.setCompany(client);
	    		final String userId = UUID.randomUUID().toString();
	    		user.setUserId(userId);
	    		user.setImageFile(lineData[0]);
	    		userMap.put(lineData[0], user);
        }
    }
    
    private String convertKeyToClient(String key) {
    		String clientKey = key.split("[.]")[0];
    		if (clientKey.indexOf('+') > -1) {
    			return clientKey.replaceAll("[+]", " ");
    		}
    		return clientKey;
    }
}